# The Galaxy's Best Smuggler - Local Copy

## Setup
This challenge requires the use of Docker. See https://docs.docker.com/engine/install/.

Navigate to the directory with `docker-compose.yaml` and run:
```
$ docker compose up -d --build
```

The game will be available at `localhost:8000` and the proxy can be directly accessed at `localhost:8001`.

To stop the containers, run:
```
$ docker compose down -v
```

## Gameplay
Sabacc (or at least this terrible, terrible rendition of it) is a blackjack-style game where the sweet spot is 20, and you can only make one move per turn.

When you first arrive on the site, click on join game to start. Your opponent will make the first move.

At every turn, you can make one of 3 moves:

Hit: Draw a new card from the deck, and add it to your hand.
Stand: End your turn without taking a card.
Reveal: Place your hand on the table face up, and force your opponent to do the same. The winner will be judged. You cannot do this on the move that opens the game.

Simply win the game to get the flag. Surely your opponent isn't cheating in any way. Right?

## About the Challenge
This challenge is not easy, as it introduces a non-trivial class of vulnerabilities not covered during training. If you're stuck (and even if you're not), feel free to refer to these hints (rot13):

- How does this website work?
    - Gur punyyratr vaibyirf lbh naq na bccbarag obg znxvat erdhrfgf gb n prageny tnzr freire gung unaqyrf ohfvarff ybtvp. Gur tnzr freire hfrf Thavpbea.
    - Nyy UGGC erdhrfgf, rvgure sebz gur obg be sebz lbh, cnff guebhtu n cebkl. Guvf punyyratr hfrf UNCebkl.
- Where is the vulnerability?
    - Gur wninfpevcg naq vagresnpr ner whfg sbe fubj.
    - Gur tnzr ybtvp vf, nf sne nf V'z njner, frpher. Gur ihyarenovyvgl yvrf ryfrjurer.
    - Guvf punyyratr pyhrf n pregnva pynff bs jro ihyarenovyvgvrf va obgu vgf anzr naq punyyratr grkg. Gel Tbbtyr. Cbegfjvttre zvtug nyfb or urycshy.
- I know what the vulnerability is, but I can't see how it applies to this challenge.
    - Lbhe bccbarag xrrcf jvaavat orpnhfr gurl'er noyr gb erirny gurve unaq evtug nsgre lbhe svefg ghea. N pregnva cnve bs qvntenzf ba Cbegfjvttre zvtug or urycshy.
- I'm having trouble getting anything to work.
    - Guvf punyyratr vf PY.GR. N pregnva PIR vf vaibyirq.
    - Ner lbh fraqvat erdhrfgf gb gur cebkl qverpgyl?
    - Erzrzore gung Thavpbea fcnjaf zhygvcyr guernqf cre jbexre. Fzhttyvat bar bs gurz jba'g or rabhtu.

These tools will help you, should you choose to use them:
- https://github.com/siemens/edgeshark, allowing you to capture packets between docker containers and view them in Wireshark.
- https://docs.python.org/3/howto/sockets.html, allowing you to send raw HTTP packets.